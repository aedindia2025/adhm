$(document).ready(function () {
	// var table_id 	= "hostel_type_datatable";
	init_datatable(table_id,form_name,action);
    get();
});

var company_name 	= sessionStorage.getItem("company_name");
var company_address	= sessionStorage.getItem("company_name");
var company_phone 	= sessionStorage.getItem("company_name");
var company_email 	= sessionStorage.getItem("company_name");
var company_logo 	= sessionStorage.getItem("company_name");

var form_name 		= 'Hostel Type';
var form_header		= '';
var form_footer 	= '';
var table_name 		= '';
var table_id 		= 'maintanance_datatable';
var action 			= "datatable";
function get_table(){
    
    init_datatable(table_id,form_name,action);
}


function init_datatable(table_id='',form_name='',action='') 
{
    var status = $("#approve_status").val();
	var table = $("#"+table_id);
    
	var data 	  = {
        "status"    : status,
		"action"	: action, 
	};
	var ajax_url = sessionStorage.getItem("folder_crud_link");

	var datatable = table.DataTable({
	
		"ajax"		: {
            destroy : true,
            url 	: ajax_url,
            type 	: "POST",
            data 	: data
        },
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'copyHtml5',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    },
                    title: 'Hostel Type'
                },
                {
                    extend: 'csvHtml5',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    },
                    title: 'Hostel Type',
                    filename: 'hostel_type'
                },
                {
                    extend: 'excelHtml5',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    },
                    title: 'Hostel Type',
                    filename: 'hostel_type'
                },
                {
                    extend: 'pdfHtml5',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    },
                    title: 'Hostel Type',
                    filename: 'hostel_type'
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    },
                    title: 'Hostel Type'
                }
            ]
        });
    
}

function maintanance_cu(unique_id = "") {
    var internet_status  = is_online();
    var data = new FormData();
    if (!internet_status) {
        sweetalert("no_internet");
        return false;
    }
    var hostel_id = $("#hostel_id").val();
    var hostel_name = $("#hostel_name").val();
    var district_id = $("#district_id").val();
    var taluk_id = $("#taluk_id").val();
    var warden_name = $("#warden_name").val();
    var warden_id = $("#warden_id").val();
    var maintanance_no = $("#maintanance_no").val();
    var asset_category = $("#asset_category").val();
    var asset_name = $("#asset_name").val();
    var academic_year = $("#academic_year").val();
    var description = $("#description").val();
    var spend_amount = parseInt($("#spend_amount").val());
    var unique_id = $("#unique_id").val();


    // var is_form = form_validity_check("was-validated");
    var image_s = $("#test_file");

	var files = document.getElementById('test_file').files;

	if (image_s != '') {
		var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.pdf|\.xlsx|\.xls)$/i;  // Regular expression for allowed extensions
		for (var i = 0; i < image_s.length; i++) {
			if (!allowedExtensions.test(files[i].name)) {
				// sweetalert('doc_error');
				// alert('Please select only image files (JPEG, JPG, PNG, GIF) or PDF and Excel files.');
				var errorMessageSpan = document.getElementById("error_message");
				errorMessageSpan.textContent = "Error: Only PDF, images (JPG, JPEG, PNG, GIF), and Excel files (XLSX, XLS) are allowed.";
			} else {
				data.append("test_file", document.getElementById('test_file').files[i]);
			}
		}
	} else {
		data.append("test_file", '');
	}

        		

        data.append("hostel_id", hostel_id);
        data.append("hostel_name", hostel_name);
        data.append("district_id", district_id);
        data.append("taluk_id", taluk_id);
        data.append("warden_name", warden_name);
        data.append("warden_id", warden_id);
        data.append("maintanance_no", maintanance_no);
        data.append("asset_category", asset_category);
        data.append("asset_name", asset_name);
        data.append("academic_year", academic_year);
        data.append("description", description);
        data.append("spend_amount", spend_amount);
        
        data.append("action", "createupdate");

        var ajax_url = sessionStorage.getItem("folder_crud_link");
        var url      = sessionStorage.getItem("list_link");

        // console.log(data);
        $.ajax({
			type 	: "POST",
			url 	: ajax_url,
			data 	: data,
            cache: false,
			contentType: false,
			processData: false,
			method: 'POST',
			beforeSend 	: function() {
				$(".createupdate_btn").attr("disabled","disabled");
				$(".createupdate_btn").text("Loading...");
			},
			success		: function(data) {

				var obj     = JSON.parse(data);
				var msg     = obj.msg;
				var status  = obj.status;
				var error   = obj.error;

				if (!status) {
					url 	= '';
                    $(".createupdate_btn").text("Error");
                    // console.log(error);
				} else {
					if (msg=="already") {
						// Button Change Attribute
						url 		= '';

						$(".createupdate_btn").removeAttr("disabled","disabled");
						if (unique_id) {
							$(".createupdate_btn").text("Update");
						} else {
							$(".createupdate_btn").text("Save");
						}
					}
				}

				sweetalert(msg,url);
			},
			error 		: function(data) {
				alert("Network Error");
			}
		});


    // } else {
    //     sweetalert("form_alert");
    // }
}

function maintanance_delete(unique_id = "") {

	var ajax_url = sessionStorage.getItem("folder_crud_link");
	var url      = sessionStorage.getItem("list_link");
	
	confirm_delete('delete')
	.then((result) => {
		if (result.isConfirmed) {

			var data = {
				"unique_id" 	: unique_id,
				"action"		: "delete"
			}

			$.ajax({
				type 	: "POST",
				url 	: ajax_url,
				data 	: data,
				success : function(data) {

					var obj     = JSON.parse(data);
					var msg     = obj.msg;
					var status  = obj.status;
					var error   = obj.error;

					if (!status) {
						url 	= '';
						
					} else {
						init_datatable(table_id,form_name,action);
					}
					sweetalert(msg,url);
				}
			});

		} else {
			// alert("cancel");
		}
	});
}

function get_asset_name() {

    var asset_category = $("#asset_category").val();

// alert(asset_category);
var ajax_url = sessionStorage.getItem("folder_crud_link");

    if (asset_category) {
        var data = {
            "asset_category": asset_category,
            "action": "get_asset_name",
        }

        $.ajax({
            type: "POST",
            url: "folders/maintanance/crud.php",
            data: data,
            success: function (data) {

                if (data) {
                    $("#asset_name").html(data);
                }
            }
        });
    }
}

function get_asset_count() {

    var asset_name = $("#asset_name").val();
// alert(asset_name);

var ajax_url = sessionStorage.getItem("folder_crud_link");

    if (asset_name) {
        var data = {
            "asset_name": asset_name,
            "action": "get_asset_count"
        }

        $.ajax({
            type: "POST",
            url: ajax_url,
            data: data,
            success: function (data) {
// alert(data);
var obj     = JSON.parse(data);
					var quantity     = obj.quantity;

                if (quantity) {

                    $("#existing_count").val(quantity);
                }
            }
        });
    }
}

function check_count(){

    var existing_count = parseInt($("#existing_count").val());
    var defect_count = parseInt($("#defect_count").val());
    
    if(defect_count <= existing_count){
        
        $("#defect_count").val(defect_count);
    }else{
        alert("Defect Count Must Be lower Than Existing Count");
        $("#defect_count").val('');
    }
}

function print_pdf(file_name)
	{
		
		 onmouseover=window.open('uploads/maintanance/' + file_name,'onmouseover', 'height=600,width=900,scrollbars=yes,resizable=no,left=200,top=150,toolbar=no,location=no,directories=no,status=no,menubar=no');
	}

    function print_view(file_name)
    {
       onmouseover= window.open('uploads/maintanance/'+file_name,'onmouseover','height=600,width=900,scrollbars=yes,resizable=no,left=200,top=150,toolbar=no,location=no,directories=no,status=no,menubar=no');
    }  

