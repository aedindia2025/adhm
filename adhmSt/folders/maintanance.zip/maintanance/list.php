<style>
.new{
    float:right;
}

</style>

<div class="content-page">
<div class="content">
<!-- Start Content-->
<div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-10">
            <div class="page-title-box">                                    
            
            <h4 class="page-title">Maintenance</h4>
            </div>
            </div>
            <div class="col-md-2 align-self-center">
            <div class="page-title-right new">
            <form class="d-flex">
                                <?php echo btn_add($btn_add); ?>
                            </form>
           
            </div>
            </div>
        </div>
     
                                                <div class="row mb-3">
                                                <div class="col-3">
                                            <!-- <label for="example-select" class="form-label">Status:</label>  
                                                  <select id="approve_status" class="form-control" required>  
                                                    <option value=0>Pending</option>
                                                    <option value=1>Completed</option>
                                                    <option value=2>Cancelled</option>
                                                  </select> -->
                                                </div>
                                                <!-- <div class="col-3">    -->
                                                <!-- <label for="example-select" class="form-label">Academic Year</label>  
                                                <div class="input-group">
                                    <input type="text" class="form-control form-control-light" id="dash-daterange">
                                    <span class="input-group-text thme-colo  border-primary text-white">
                                        <i class="mdi mdi-calendar-range font-13"></i>
                                    </span> -->
                                <!-- </div> -->
                                                <!-- </div> -->
                                                
                                        
                                <div class="col-3">
                        <!-- <form class="d-flex"> -->
        
                            <!-- <button class="btn btn-primary" style="float:left;" onclick="get_table()">Filter</button> -->
                        <!-- </form> -->
                                                </div>
                                                </div>


                 
                       
                        
    <div class="row">
    <div class="col-12">
    <div class="card">
    <div class="card-body">
        <table id="maintanance_datatable"     class="table dt-responsive nowrap w-100">
            <thead>
                <tr>
                    <th>S.no</th>
                    <th>Date</th>
                    <th>Maintanance No</th>
                    <th>Asset Category</th>
                    <th>Asset name</th>
                    <th>Invoice</th>
                    <!-- <th>Status</th> -->
                    <!-- <th>Status</th> -->
                   	<th>Action</th>
                </tr>
            </thead>
            <tbody>
               
            </tbody>
        </table>

    </div>
    </div>
    </div>
    </div>
                
                
</div>
</div>
</div>


<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script>
    new DataTable('#demo');
</script>
