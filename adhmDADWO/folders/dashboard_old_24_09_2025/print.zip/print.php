    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-default-stylesheet" />
    <style>
    	body {
    		background-color: #fff;
    	}

    	.zone_recom {
    		border: 1px solid #ccc;
    		padding: 14px;
    		margin-bottom: 30px;
    	}

    	.box1 h3 {
    		background-color: #f0f0f0;
    		padding: 4px;
    		text-align: center;
    		font-weight: 700;
    		color: #333;
    		font-size: 14px;
    	}

    	.bd-highlight {
    		font-size: 14px;
    		color: #444;
    	}

    	.contn_info.d-flex h6 {
    		text-align: right;
    		font-size: 11.5px;
    		margin-bottom: 4px;
    	}

    	.contn_info.d-flex h5 {
    		color: #000;
    		font-size: 11.5px;
    		margin-bottom: 4px;
    	}

    	.contn_info.d-flex p {
    		margin-bottom: 4px;
    	}

    	.zone_boxbor {

    		margin-bottom: 20px;

    	}

    	.zone_recom1,
    	.zone_recom3 {
    		border: 1px solid #ccc;
    		padding: 4px;
    	}

    	.zone_recom2 {
    		border: 1px solid #ccc;
    		padding: 4px;
    	}

    	.col-md-4 {
    		width: 33.33333333%;
    		padding-left: 5px;
    		padding-right: 5px;
    	}

    	.col-md-8 {
    		flex: 0 0 auto;
    		width: 66.66666667%;
    	}

    	.col-md-4.wid1 {
    		width: 45%;
    	}

    	.col-md-8.wid2 {
    		width: 55%;
    	}

    	table,
    	th,
    	td {
    		border: 1px solid #ccc;
    		border-collapse: collapse;
    	}

    	th,
    	td {
    		padding: 5px;
    		text-align: left;
    	}

    	.print_icon {
    		text-align: right;
    		font-size: 33px;
    	}
    </style>
    <?php

	include '../../config/dbconfig.php';

	if (isset($_GET["complaint_type"])) {
		$complaint_type = disname($_GET['complaint_type'] . " Complaints");
	}

	if ($_GET['branch_name']) {
		$branch_id = get_reginal_name($_GET["branch_name"]);
		$branch_name = $branch_id[0]['branch_name'];
	} else {
		$branch_name = "All Region";
	}



	?>

    <div class="container-fluid" style="background-color:#fff;">
    	<div class="compl_print pt-2">
    		<div class="zone_boxbor">
    			<div class="row">

    				<div class="col-md-12">

    					<img class="mb-3" src="../../assets/images/hed1.jpg" width="100%" />

    					<div class="row">
    						<div class="col-md-6">
    							<h6> </h6>
    						</div>
    						<div class="col-md-6" style="text-align:right;">
    							<h6>DATE : <?= $today  =  date('d-m-y'); ?></h6>
    						</div>
    					</div>
    					<center>
    						<h3><?= $branch_name; ?> - <?= $complaint_type; ?></h3>
    					</center>

    					<div class="zone_recom3">
    						<div class="box1">
    							<table cellspacing="0" cellpadding="0" class="" width="100%" style="font-family: monospace;">
    								<thead class="colspanHead">
    									<tr>
    										<th width="5%" colspan="1" class="blankCell">S.No</th>
    										<th width="10%" colspan="1" class="blankCell">Entry Date</th>
    										<th width="10%" colspan="1" class="blankCell">complaint_no</th>
    										<th width="10%" colspan="1" class="blankCell">Crm Booking No</th>
    										<th width="10%" colspan="1" class="blankCell">branch_name</th>
    										<th width="10%" colspan="1" class="blankCell">Engineer</th>
    										<th width="15%" colspan="1" class="blankCell">call_type</th>
    										<th width="10%" colspan="1" class="blankCell">service_type</th>

    									</tr>
    								</thead>
    								<?php
									$start = 0;
									$table_main = "view_call_booking";
									$today  =  date('Y-m-d');
									$user_type_unique_id = $_GET['user_type_unique_id'];
									$region_name = $_GET["region_name"];
									$branch_name = $_GET["branch_name"];
									$branch_id = $_GET['branch_id'];
									$cate = $_GET['cate'];

									if ($_GET['complaint_type'] == "opening") {
										$where_list = "entry_date < '" . $today . "' and    (call_station = 0 )  and is_delete = 0";
									}

									if ($_GET['complaint_type'] == "new") {
										$where_list = "entry_date = '" . $today . "' and  (call_station = 0 or call_station = 1) and is_delete = 0";
									}

									if ($_GET['complaint_type'] == "completed") {
										$where_list = " entry_date = '" . $today . "' and call_station = 1 and is_delete = 0";
									}

									if ($_GET['complaint_type'] == "pending") {
										$where_list = "entry_date = '" . $today . "' and  (call_station = 0) and is_delete = 0";
									}
									if ($user_type_unique_id != '5f97fc3257f2525529' && $cate == 1) {
										$where_list .= " AND regional_name = '$region_name'";
									} else {
										$where_list .= "";
									}
									if ($branch_name != '') {
										$where_list .= ' and regional_name = "' . $branch_name . '"';
									} else if ($branch_name == '') {
										$where_list .= '';
									}
									if ($branch_id != '' && $cate == 2) {
										$where_list .= ' and branch_name = "' . $branch_id . '"';
									} else {
										$where_list .= '';
									}
									if ($branch_name == '' && $user_type_unique_id == '5f97fc3257f2525529' || $user_type_unique_id == '64c77c51b508613611') {
										$columns_list    = [
											"@a:=@a+1 s_no",
											"entry_date",
											"complaint_no",
											"booking_no",
											"branch_name",
											"engineer",
											"call_type",
											"service_type"
										];
									} else if ($branch_name != '' && $user_type_unique_id == '5f97fc3257f2525529' || $user_type_unique_id == '64c77c51b508613611') {
										$columns_list    = [
											"@a:=@a+1 s_no",
											"entry_date",
											"complaint_no",
											"booking_no",
											"branch_name",
											"engineer",
											"call_type",
											"service_type"
										];
									} else if ($user_type_unique_id != '5f97fc3257f2525529' && $cate == 1) {
										$columns_list    = [
											"@a:=@a+1 s_no",
											"entry_date",
											"complaint_no",
											"booking_no",
											"branch_name",
											"engineer",
											"call_type",
											"service_type"
										];
									}
									if ($user_type_unique_id != '5f97fc3257f2525529' && $cate == 2) {
										$columns_list    = [
											"@a:=@a+1 s_no",
											"entry_date",
											"complaint_no",
											"booking_no",
											"branch_name",
											"engineer",
											"call_type",
											"service_type"
										];
									}

									$table_details_list  = [
										$table_main . ", (SELECT @a:= " . $start . ") AS a ",
										$columns_list
									];

									$result         = $pdo_att->select($table_details_list, $where_list);

									if ($result->status) {

										$res_array      = $result->data;

										$table_data     = "";
										if (count($res_array) == 0) {
											$table_data .= "<tr>";

											$table_data .= "<td colspan=9 style = 'text-align : center'>" . 'No Data Found' . "</td>";

											$table_data .= "</tr>";
										} else {
											foreach ($res_array as $key => $value) {
												$ent_date = date('Y-m-d');
												$date1 = date_create($value['entry_date']);
												$date2 = date_create($ent_date);
												$diff = date_diff($date1, $date2);
												$current_date =  $diff->format("%a");

												switch ($value['call_station']) {
													case 1:
														$stage_status = "<span style='font-size:12px;font-weight : bold;color:Orange'>In Progress</span>";
														break;
													case 2:
														$stage_status = "<span style='font-size:12px;font-weight : bold;color:#1fcb6b'>Completed</span>";
														break;
													case 3:
														$stage_status = "<span style='font-size:12px;font-weight : bold;color:Red'>Cancel</span>";
														break;
													default:
														$stage_status = "<span style='font-size:12px;font-weight : bold;color:blue'>Pending</span>";
														break;
												}

												$res = branch_name($value['branch_name']);
												$branch_name = $res[0]['branch_name'];
												$value['entry_date']        = disdate($value['entry_date']);
												$table_data .= "<tr>";

												$table_data .= "<td>" . $value['s_no'] . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $value['entry_date'] . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $value['complaint_no'] . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $value['booking_no'] . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $branch_name . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $value['engineer'] . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $value['call_type'] . "</td>";
												$table_data .= "<td style = 'text-align : left'>" . $value['service_type'] . "</td>";


												$table_data .= "</tr>";
											}
										}
									}
									?>
    								<tbody>
    									<?php echo $table_data; ?>
    								</tbody>
    							</table>
    						</div>
    					</div>
    				</div>


    			</div>
    		</div>


    	</div>
    </div>
    <?php
	function get_ending_date($assign_by, $department, $stage)
	{
		global $pdo;

		$table_name    = "periodic_creation_sub";
		$where         = [];
		$table_columns = [
			"ending_count",
		];

		$table_details = [
			"periodic_creation_sub",
			$table_columns
		];

		$where  = "department_name = '" . $department . "' and stage = " . $stage . " and is_delete = 0 and form_unique_id != ''";


		$cnt_status = $pdo->select($table_details, $where);
		//echo $cnt_status;
		if (!($cnt_status->status)) {

			print_r($cnt_status);
		} else {

			if (!empty($cnt_status->data[0])) {
				$cnt_sts    = $cnt_status->data[0]['ending_count'];
			} else {
				$cnt_sts    = "";
			}
		}
		return $cnt_sts;
	}
	?>

    <script>
    	function excel() {

    		var link = 'excel.php';
    		window.location = link;
    	}
    </script>