# Changelog
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]
Nothing

## 0.1.2 2016-02-16
### Fixed
Fix examples upload folder didn't included in repository because it was empty


## 0.1.1 2016-02-15
### Fixed
Fix empty() function issue with function call as argument in PHP version below 5.5

## 0.1.0 2016-02-15
### Added
Base package classes and files [Initial Release]