<?php

namespace Alirdn\SecureUPload\Logger;

function error_log($log_text)
{
    return $log_text;
}