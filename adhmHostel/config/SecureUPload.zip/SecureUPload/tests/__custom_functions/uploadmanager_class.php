<?php

namespace Alirdn\SecureUPload\Upload;

function time()
{
    return 123456789;
}

function date($type)
{
    return $type;
}