# Contributing
Contribute to SecureUPload via Pull Requests.

# Rules
- **Each feature one pull request**.
- **PSR-2 compatible codes only**.
- **Urgent: Write tests**.

# Contributions are welcomed and will be credited.